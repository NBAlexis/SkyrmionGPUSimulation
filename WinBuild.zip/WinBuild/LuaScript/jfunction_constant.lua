-- Exchange Strength is constant
function GetJValueByLatticeIndex(x, y)
    return 1.0
end
